
import json


def lambda_handler(event, context): 

    try:
        GLUE_JOB_CONFIGURATION_DYNAMO_DB_TABLE_NAME= "glue-job-configurations"

        record = event['Records'][0]
        # extracing the bucket and object key
        bucket_name = record['s3']['bucket']['name']
        object_key =record['s3']['object']['key']

        # obect format
        object_foramt = object_key.split('.')[-1]

        print(bucket_name, object_key, object_foramt)

        # querying for the glue job configuration
        response = dynamodb.get_item(
            TableName=GLUE_JOB_CONFIGURATION_DYNAMO_DB_TABLE_NAME,
            Key={'format': {'S': object_foramt}}
        )
        print(response)
        if 'Item' not in response:
            print(f"No Glue job configured for format: {format_name}")
            return {"status": "no job found"}

        # taking the glue_job_name
        glue_job_name = response['Item'].get('job_name', {}).get('S')

        print(f"Starting Glue job: {glue_job_name}")


        

        return {
            'statusCode': 200,
            'body': json.dumps('Job run successfully')
        }
    
    except Exception as e :
        print(e)
        return {
            'statusCode': 200,
            'body': json.dumps('Something went wrong')
        }

